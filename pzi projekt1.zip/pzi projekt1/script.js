 // Selektori za prvi datepicker
 const datepicker = document.querySelector(".datepicker");
 const dateInput = document.querySelector(".date-input");
 const yearInput = datepicker.querySelector(".year-input");
 const monthInput = datepicker.querySelector(".month-input");
 const cancelBtn = datepicker.querySelector(".cancel");
 const applyBtn = datepicker.querySelector(".apply");
 const nextBtn = datepicker.querySelector(".next1");
 const prevBtn = datepicker.querySelector(".prev1");
 const dates = datepicker.querySelector(".dates");

 // Selektori za drugi datepicker
 const dateInput2 = document.querySelector('#datepicker2-input');
 const datepicker2 = document.querySelector('#datepicker2');
 const yearInput2 = datepicker2.querySelector(".year-input");
 const monthInput2 = datepicker2.querySelector(".month-input");
 const cancelBtn2 = datepicker2.querySelector(".cancel");
 const applyBtn2 = datepicker2.querySelector(".apply");
 const nextBtn2 = datepicker2.querySelector(".next1");
 const prevBtn2 = datepicker2.querySelector(".prev1");
 const dates2 = datepicker2.querySelector(".dates");

 // Inicijalne vrijednosti za datum
 let selectedDate = new Date();
 let year = selectedDate.getFullYear();
 let month = selectedDate.getMonth();

 dateInput2.disabled = true;

 // Event listeneri za prvi datepicker
 dateInput.addEventListener("click", () => {
     datepicker.hidden = false;
 });

 cancelBtn.addEventListener("click", () => {
     datepicker.hidden = true;
 });

 applyBtn.addEventListener("click", () => {
     if (!selectedDate) {
         alert("Odaberite početni datum prije nego što nastavite.");
         return;
     }
     dateInput.value = selectedDate.toLocaleDateString("en-US", {
         year: "numeric",
         month: "2-digit",
         day: "2-digit",
     });

     dateInput2.disabled = false;
     datepicker.hidden = true;
 });

 nextBtn.addEventListener("click", () => {
     if (month === 11) year++;
     month = (month + 1) % 12;
     displayDates();
 });

 prevBtn.addEventListener("click", () => {
     if (month === 0) year--;
     month = (month - 1 + 12) % 12;
     displayDates();
 });

 monthInput.addEventListener("change", () => {
     month = monthInput.selectedIndex;
     displayDates();
 });

 yearInput.addEventListener("change", () => {
     year = yearInput.value;
     displayDates();
 });

 const updateYearMonth = () => {
     monthInput.selectedIndex = month;
     yearInput.value = year;
 };

 const handleDateClick = (e) => {
     const button = e.target;
     const selected = dates.querySelector(".selected");
     if (selected) selected.classList.remove("selected");
     button.classList.add("selected");
     selectedDate = new Date(year, month, parseInt(button.textContent));
 };

 const displayDates = () => {
     updateYearMonth();
     dates.innerHTML = "";

     const lastOfPrevMonth = new Date(year, month, 0);
     for (let i = 0; i <= lastOfPrevMonth.getDay(); i++) {
         const text = lastOfPrevMonth.getDate() - lastOfPrevMonth.getDay() + i;
         const button = createButton(text, true, -1);
         dates.appendChild(button);
     }

     const lastOfMOnth = new Date(year, month + 1, 0);
     for (let i = 1; i <= lastOfMOnth.getDate(); i++) {
         const button = createButton(i, false);
         button.addEventListener("click", handleDateClick);
         dates.appendChild(button);
     }

     const firstOfNextMonth = new Date(year, month + 1, 1);
     for (let i = firstOfNextMonth.getDay(); i < 7; i++) {
         const text = firstOfNextMonth.getDate() - firstOfNextMonth.getDay() + i;
         const button = createButton(text, true, 1);
         dates.appendChild(button);
     }
 };

 const createButton = (text, isDisabled = false, type = 0) => {
     const currentDate = new Date();
     let comparisonDate = new Date(year, month + type, text);

     const isToday =
         currentDate.getDate() === text &&
         currentDate.getFullYear() === year &&
         currentDate.getMonth() === month;

     const selected = selectedDate.getTime() === comparisonDate.getTime();

     const button = document.createElement("button");
     button.textContent = text;
     button.disabled = isDisabled;
     button.classList.toggle("today", isToday && !isDisabled);
     button.classList.toggle("selected", selected);
     return button;
 };

 displayDates();

 // Inicijalne vrijednosti za drugi datepicker
 let selectedDate2 = new Date();
 let year2 = selectedDate2.getFullYear();
 let month2 = selectedDate2.getMonth();

 // Event listeneri za drugi datepicker
 dateInput2.addEventListener("click", () => {
     if (!selectedDate) {
         alert("Prvo odaberite početni datum.");
         return;
     }
     datepicker2.hidden = false;
 });

 cancelBtn2.addEventListener("click", () => {
     datepicker2.hidden = true;
 });

 applyBtn2.addEventListener("click", () => {
     dateInput2.value = selectedDate2.toLocaleDateString("en-US", {
         year: "numeric",
         month: "2-digit",
         day: "2-digit",
     });
     datepicker2.hidden = true;
 });

 nextBtn2.addEventListener("click", () => {
     if (month2 === 11) year2++;
     month2 = (month2 + 1) % 12;
     displayDates2();
 });

 prevBtn2.addEventListener("click", () => {
     if (month2 === 0) year2--;
     month2 = (month2 - 1 + 12) % 12;
     displayDates2();
 });

 monthInput2.addEventListener("change", () => {
     month2 = monthInput2.selectedIndex;
     displayDates2();
 });

 yearInput2.addEventListener("change", () => {
     year2 = yearInput2.value;
     displayDates2();
 });

 const updateYearMonth2 = () => {
     monthInput2.selectedIndex = month2;
     yearInput2.value = year2;
 };

 const handleDateClick2 = (e) => {
     const button = e.target;
     const selected = dates2.querySelector(".selected");
     if (selected) selected.classList.remove("selected");
     button.classList.add("selected");

     let selectedTemp = new Date(year2, month2, parseInt(button.textContent));
     if (selectedTemp < selectedDate) {
         alert("Krajnji datum ne može biti prije početnog.");
         return;
     }

     selectedDate2 = selectedTemp;
 };

 const displayDates2 = () => {
     updateYearMonth2();
     dates2.innerHTML = "";

     const lastOfPrevMonth2 = new Date(year2, month2, 0);
     for (let i = 0; i <= lastOfPrevMonth2.getDay(); i++) {
         const text = lastOfPrevMonth2.getDate() - lastOfPrevMonth2.getDay() + i;
         const button = createButton2(text, true, -1);
         dates2.appendChild(button);
     }

     const lastOfMonth2 = new Date(year2, month2 + 1, 0);
     for (let i = 1; i <= lastOfMonth2.getDate(); i++) {
         const button = createButton2(i, false);
         button.addEventListener("click", handleDateClick2);
         dates2.appendChild(button);
     }

     const firstOfNextMonth2 = new Date(year2, month2 + 1, 1);
     for (let i = firstOfNextMonth2.getDay(); i < 7; i++) {
         const text = firstOfNextMonth2.getDate() - firstOfNextMonth2.getDay() + i;
         const button = createButton2(text, true, 1);
         dates2.appendChild(button);
     }
 };

 const createButton2 = (text, isDisabled = false, type = 0) => {
     const currentDate = new Date();
     let comparisonDate = new Date(year2, month2 + type, text);

     const isToday =
         currentDate.getDate() === text &&
         currentDate.getFullYear() === year2 &&
         currentDate.getMonth() === month2;

     const selected = selectedDate2.getTime() === comparisonDate.getTime();

     const button = document.createElement("button");
     button.textContent = text;
     button.disabled = isDisabled;
     button.classList.toggle("today", isToday && !isDisabled);
     button.classList.toggle("selected", selected);
     return button;
 };

 displayDates2();

 // Lokacije i autocomplete
 const locationInput = document.getElementById("event-location");
 let locations = [];

 (async () => {
     try {
         const response = await fetch("https://raw.githubusercontent.com/samayo/country-json/refs/heads/master/src/country-by-capital-city.json");
         const data = await response.json();
         locations = data.map(item => item.city ? `${item.city}, ${item.country}` : item.country);
     } catch (error) {
         console.error("Došlo je do greške pri učitavanju lokacija.", error);
     }
 })();

 const filterSuggestions = (inputValue) => {
     return locations.filter(location =>
         location.toLowerCase().startsWith(inputValue.toLowerCase())
     );
 };

 locationInput.addEventListener("input", () => {
     const suggestionsContainer = document.getElementById("suggestions");
     suggestionsContainer.innerHTML = "";

     const inputValue = locationInput.value.trim();
     if (!inputValue) return;

     const filteredSuggestions = filterSuggestions(inputValue);

     filteredSuggestions.forEach(suggestion => {
         const suggestionItem = document.createElement("div");
         suggestionItem.classList.add("suggestion-item");
         suggestionItem.textContent = suggestion;

         suggestionItem.addEventListener("click", () => {
             locationInput.value = suggestion;
             suggestionsContainer.innerHTML = "";
         });

         suggestionsContainer.appendChild(suggestionItem);
     });
 });

 document.addEventListener("click", (e) => {
     if (!locationInput.contains(e.target)) {
         document.getElementById("suggestions").innerHTML = "";
     }
 });

 // Modal za kreiranje događaja
 const modal = document.getElementById("event-modal");
 const createEventBtn = document.getElementById("create-event-btn");
 const closeModalBtn = document.querySelector(".close");

 if (modal && createEventBtn && closeModalBtn) {
     function openModal() {
         modal.style.display = "block";
     }

     function closeModal() {
         modal.style.display = "none";
     }

     createEventBtn.addEventListener("click", function (event) {
         event.preventDefault();
         openModal();
     });

     closeModalBtn.addEventListener("click", closeModal);

     window.addEventListener("click", function (event) {
         if (event.target === modal) {
             closeModal();
         }
     });
 }

 // Spremanje i prikaz događaja
 const saveButton = document.getElementById("save-event");
 const eventList = document.getElementById("event-list");
 const filterInput = document.getElementById("location-filter");

 if (saveButton && eventList && filterInput) {
     saveButton.addEventListener("click", function () {
         const title = document.getElementById("event-title").value;
         const location = document.getElementById("event-location").value;
         const description = document.getElementById("event-description").value;
         const startDate = document.getElementById("start-date").value;
         const endDate = document.getElementById("datepicker2-input").value;
         const imageInput = document.getElementById("event-image");

         if (!title || !location || !description || !startDate || !endDate) {
             alert("Sva polja su obavezna.");
             return;
         }

         let imageURL = "";
         if (imageInput.files.length > 0) {
             const reader = new FileReader();
             reader.onload = function (e) {
                 saveEvent(title, location, description, startDate, endDate, e.target.result);
                 displayEvents();
                 closeModal1();
             };
             reader.readAsDataURL(imageInput.files[0]);
         } else {
             saveEvent(title, location, description, startDate, endDate, imageURL);
             displayEvents();
             closeModal1();
         }
     });

     function saveEvent(title, location, description, startDate, endDate, imageURL) {
         let events = JSON.parse(localStorage.getItem("events")) || [];
         const newEvent = { title, location, description, startDate, endDate, imageURL };
         events.push(newEvent);
         localStorage.setItem("events", JSON.stringify(events));
     }

     function displayEvents(filteredEvents = null) {
         eventList.innerHTML = "";
         let events = JSON.parse(localStorage.getItem("events")) || [];

         if (filteredEvents !== null) {
             events = filteredEvents;
         }

         events.forEach((event, index) => {
             const eventCard = document.createElement("div");
             eventCard.classList.add("event-card");
             eventCard.innerHTML = `
                 <h3>${event.title}</h3>
                 ${event.imageURL ? `<img src="${event.imageURL}" alt="Slika događaja" />` : ""}
                 <p><strong>Početni datum:</strong> ${event.startDate}</p>
                 <p><strong>Krajnji datum:</strong> ${event.endDate}</p>
                 <p><strong>Lokacija:</strong> ${event.location}</p>
                 <p><strong>Opis:</strong> ${event.description}</p>
                 <button class="delete-btn" data-index="${index}">Obriši</button>
             `;
             eventList.appendChild(eventCard);
         });

         document.querySelectorAll(".delete-btn").forEach(button => {
             button.addEventListener("click", function () {
                 deleteEvent(this.getAttribute("data-index"));
             });
         });
     }

     function deleteEvent(index) {
         let events = JSON.parse(localStorage.getItem("events")) || [];
         events.splice(index, 1);
         localStorage.setItem("events", JSON.stringify(events));
         displayEvents();
     }

     function filterEvents() {
         let searchValue = filterInput.value.trim().toLowerCase();
         let events = JSON.parse(localStorage.getItem("events")) || [];

         let filteredEvents = events.filter(event => 
             event.location.toLowerCase().includes(searchValue)
         );

         displayEvents(filteredEvents);
     }

     filterInput.addEventListener("input", filterEvents);
     displayEvents();

     function closeModal1() {
         const modal = document.getElementById("event-modal");
         modal.style.display = "none";
         clearForm();
     }

     function clearForm() {
         const modal = document.getElementById("event-modal");  
         const formElements = modal.querySelectorAll("input, textarea");  
         formElements.forEach(element => {
             if (element.type === "file") {
                 element.value = ""; 
             } else {
                 element.value = ""; 
             }
         });
     }
 }